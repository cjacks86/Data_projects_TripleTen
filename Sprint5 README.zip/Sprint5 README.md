Markdown #SPRINT5PROJECT

This file includes the link to the public Tableau from Sprint 5. It investigates why there are so many returns and how to reduce the volume of returned orders.



Link to public tableau project is found below:
https://public.tableau.com/views/Sprint5_17394732961720/ReturnRatebyCategory?:language=en-US&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link



Link to Screen Recording on my Google drive that has been shared publicly:
https://drive.google.com/file/d/1A8nemMRZ5JxEdnRuehyZVAsdigQ95_kS/view?usp=sharing

