Markdown #SPRINT4PROJECT

SAVING SUPERSTORE - This project reviews the superstore's operations and how to increase its profitability to avoid bankruptcy.

Link to public tableau project is found below:

https://public.tableau.com/views/Sprint4Project_17370493392780/AvgProfitvsAvgReturnsbyState?:language=en-US&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link